
<?php $__env->startSection('content'); ?>
    <div class="modal" id="myModal">
        <form enctype="multipart/form-data" action="/produk-store" method="post" id="forms">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Tambah Produk</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
						
                        <input type="hidden" name="id" id="id">
                        <label>Kode Produk</label>
                        <input type="text" class="form-control" name="kode" id="kode">
                        <label>Nama Produk</label>
                        <input type="text" class="form-control" name="nama" id="nama">
                        <label>Foto Produk</label>
                        <input type="file" class="form-control" name="foto" id="foto">
                        <img class="img img-fluid img-thumbnail" style="max-height:250px;" id="preview">
                        <br>
                        <label>Deskripsi Produk</label>
                        <input type="text" class="form-control" name="desc" id="desc">
                        <label>Harga Produk</label>
                        <input type="text" class="form-control" name="harga" id="harga">
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>

                </div>
            </div>
        </form>
    </div>

    <div class="container">
        <br>
        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal" style="float: left" onclick="create()">
            <i class="fas fa-plus"></i> Produk
        </button>
        <h4 class="text-center">
            Master Produk
        </h4>

        <table class="table table-hover table-striped" id="dtb">
            <thead class="table-dark">
                <th>No</th>
                <th>Foto</th>
                <th>Nama Produk</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Status</th>
                <th>Waktu Publish</th>
                <th>Pengaturan</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p hidden id="id<?php echo e($d->id); ?>"><?php echo e($d->id); ?></p>
                    <p hidden id="nama<?php echo e($d->id); ?>"><?php echo e($d->ProdukNama); ?></p>
                    <p hidden id="foto<?php echo e($d->id); ?>"><?php echo e(url('storage/' . $d->ProdukFoto)); ?></p>
                    <p hidden id="desc<?php echo e($d->id); ?>"><?php echo e($d->ProdukDesc); ?></p>
                    <p hidden id="harga<?php echo e($d->id); ?>"><?php echo e($d->ProdukHarga); ?></p>
                    <p hidden id="kode<?php echo e($d->id); ?>"><?php echo e($d->ProdukKode); ?></p>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><img src="<?php echo e(url('storage/' . $d->ProdukFoto)); ?>" class="img img-fluid img-thumbnail value-img"
                                style="max-height: 75px" alt="Foto Produk"></td>
                        <td><?php echo e($d->ProdukNama); ?></td>
                        <td><?php echo e($d->ProdukDesc); ?></td>
                        <td>Rp. <?php echo e(number_format($d->ProdukHarga, 0, '', '.')); ?></td>
                        <td>
                            <?php if($d->ProdukStatus == 0): ?>
                                <i class="icon-archive text-secondary" data-toggle="tooltip" title="Draft"></i>
                            <?php elseif($d->ProdukStatus == 1): ?>
                                <i class="icon-eye text-success" data-toggle="tooltip" title="Publish"></i>
                            <?php else: ?>
                                <i class="icon-eye-slash text-danger" data-toggle="tooltip" title="Arsip"></i>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($d->ProdukWP); ?></td>
                        <td>
                            <button type="button" class="btn" onclick="edits(<?php echo e($d->id); ?>)" data-toggle="tooltip" title="Edit" data-target="#myModal"><i class="icon-edit"></i></button>|
                            <a href="<?php echo e($d->ProdukStatus ==  1 ? '#' : '/produk-publish?id='. $d->id); ?>"><i class="icon-eye text-success" data-toggle="tooltip" title="to Publish"></i></a> |
                            <a href="<?php echo e($d->ProdukStatus ==  2 ? '#' : '/produk-archive?id='. $d->id); ?>"><i class="icon-eye-slash text-danger" data-toggle="tooltip" title="to Arsip"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <br>
    </div>

    <script>
        function edits(i) {
            $('#forms').prop('action', 'produk-update');
            $('#id').val($('#id' + i).text());
            $('#nama').val($('#nama' + i).text());
            $('#desc').val($('#desc' + i).text());
            $('#harga').val($('#harga' + i).text());
            $('#kode').val($('#kode' + i).text());
            $('#preview').prop('src', $('#foto' + i).text());
        }

        function create() {
            $('#forms').prop('action', 'produk-store');
            $('#id').val('');
            $('#nama').val('');
            $('#preview').prop('src', '');
            $('#desc').val('');
            $('#harga').val('');
            $('#kode').val('');
        }

        function readUrl(input){
            if (input.files && input.files[0]){
                var reader = new FileReader();

                reader.onload = function(e){
                    $('#preview').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $('#foto').change(function(){
            readUrl(this);
        });
		
		$(function () {
		  $('[data-toggle="tooltip"]').tooltip()
		})
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application Laravel\aplikasi-laravel\resources\views\zakiyah batik\resources\views/produk.blade.php ENDPATH**/ ?>